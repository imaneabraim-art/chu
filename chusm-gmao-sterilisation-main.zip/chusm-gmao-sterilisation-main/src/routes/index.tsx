import { createFileRoute } from "@tanstack/react-router";
import { useState } from "react";
import { Phone, Mail, Siren, ShieldAlert, Wrench, Building2, CheckCircle2, Send, Info } from "lucide-react";
import { toast } from "sonner";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Textarea } from "@/components/ui/textarea";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { contactsSEBM, contactsMedexel, contactsSterilisation, type Contact } from "@/lib/data";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "Alerte & Escalade — CHUSM6A" },
      { name: "description", content: "Compteur de sécurité et escalade technique." },
    ],
  }),
  component: EscaladePage,
});

function EscaladePage() {
  const [escalated, setEscalated] = useState(false);
  const [emailSubject, setEmailSubject] = useState("");
  const [emailBody, setEmailBody] = useState("");
  const [sending, setSending] = useState(false);

  const triggerEscalation = () => {
    setEscalated(true);
    toast.success("Escalade automatique déclenchée — SMS & e-mails envoyés au SEBM, à Medexel et à la Stérilisation.");
  };

  const sendInfoEmail = () => {
    if (!emailBody.trim()) {
      toast.error("Veuillez saisir le contenu du message d'information.");
      return;
    }
    setSending(true);
    setTimeout(() => {
      setSending(false);
      setEmailSubject("");
      setEmailBody("");
      toast.success("Message d'information envoyé avec succès aux adresses sélectionnées.", {
        description: "Destinataires : ibrahssn2@gmail.com · Efakermed@gmail.com",
      });
    }, 700);
  };

  return (
    <div className="mx-auto max-w-[1600px] space-y-6 p-4 md:p-6">
      <div className="rounded-lg border-l-4 border-warning bg-warning/10 p-4">
        <div className="flex items-start gap-3">
          <Info className="mt-0.5 h-6 w-6 shrink-0 text-warning" />
          <div className="flex-1">
            <div className="text-xs font-bold uppercase tracking-wider text-warning">
              Suivi technique en cours
            </div>
            <p className="mt-1 text-sm text-foreground">
              <span className="font-semibold">Autoclave Getinge #3</span> actuellement consigné pour maintenance curative
              au sein du service de Stérilisation Centrale.
            </p>
          </div>
          <Badge className="bg-warning text-warning-foreground">
            État système : {escalated ? "Prestataire Medexel Notifié" : "En attente d'escalade"}
          </Badge>
        </div>
      </div>

      <div className="flex flex-wrap items-start justify-between gap-3">
        <div>
          <h1 className="text-2xl font-bold tracking-tight">Centre d'Information & Escalade Technique</h1>
          <p className="text-sm text-muted-foreground">
            Chaîne de mobilisation des intervenants — SEBM CHU, Prestataire Medexel (Getinge) et Service Stérilisation.
          </p>
        </div>
        <Button
          size="lg"
          variant={escalated ? "secondary" : "destructive"}
          onClick={triggerEscalation}
          disabled={escalated}
          className="font-semibold"
        >
          {escalated ? (
            <>
              <CheckCircle2 className="h-4 w-4" />
              Escalade automatique effectuée
            </>
          ) : (
            <>
              <Siren className="h-4 w-4" />
              Déclencher l'escalade automatique
            </>
          )}
        </Button>
      </div>

      <div className="grid grid-cols-1 gap-4 lg:grid-cols-3">
        <ContactColumn
          icon={<ShieldAlert className="h-5 w-5" />}
          title="Alerter le SEBM (Interne)"
          subtitle="Service des Équipements Biomédicaux et de la Maintenance — CHU"
          tone="info"
          contacts={contactsSEBM}
        />
        <ContactColumn
          icon={<Wrench className="h-5 w-5" />}
          title="Contacter Medexel (Externe Getinge)"
          subtitle="Prestataire spécialiste Getinge Maroc"
          tone="warning"
          contacts={contactsMedexel}
        />
        <ContactColumn
          icon={<Building2 className="h-5 w-5" />}
          title="Informer la Stérilisation"
          subtitle="Coordination des kits chirurgicaux bloqués"
          tone="accent"
          contacts={contactsSterilisation}
        />
      </div>

      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Mail className="h-5 w-5 text-primary" />
            Notification d'information par e-mail
          </CardTitle>
          <CardDescription>
            Diffusion sécurisée d'un message technique aux destinataires référents :
            <span className="ml-1 font-mono text-foreground">ibrahssn2@gmail.com</span> ·
            <span className="ml-1 font-mono text-foreground">Efakermed@gmail.com</span>
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="space-y-1.5">
            <Label>Objet (optionnel)</Label>
            <Input
              value={emailSubject}
              onChange={(e) => setEmailSubject(e.target.value)}
              placeholder="Ex. Point de situation — Autoclave Getinge #3"
            />
          </div>
          <div className="space-y-1.5">
            <Label>Message d'information *</Label>
            <Textarea
              rows={5}
              value={emailBody}
              onChange={(e) => setEmailBody(e.target.value)}
              placeholder="Rédiger ici la mise à jour technique destinée aux référents…"
            />
          </div>
          <div className="flex justify-end">
            <Button size="lg" onClick={sendInfoEmail} disabled={sending}>
              <Send className="h-4 w-4" />
              {sending ? "Envoi en cours…" : "Envoyer le message d'information"}
            </Button>
          </div>
        </CardContent>
      </Card>

      {escalated && (
        <Card className="border-success/40 bg-success/5">
          <CardHeader className="pb-2">
            <CardTitle className="flex items-center gap-2 text-success">
              <CheckCircle2 className="h-5 w-5" />
              Journal de l'escalade
            </CardTitle>
            <CardDescription>Notifications transmises automatiquement à {new Date().toLocaleString("fr-FR")}.</CardDescription>
          </CardHeader>
          <CardContent>
            <ul className="space-y-1.5 text-sm">
              <li>✓ SMS envoyé à Ing. A. Benbah, Tech. Mohamed et Tech. Ibrahim (SEBM CHU)</li>
              <li>✓ E-mail prioritaire transmis à Medexel S.A. (Experts Elarbi & Hamza)</li>
              <li>✓ Notification interne adressée à la Majeure Ahlam (Service Stérilisation)</li>
              <li>✓ État système mis à jour : <span className="font-semibold">Prestataire Medexel Notifié</span></li>
            </ul>
          </CardContent>
        </Card>
      )}
    </div>
  );
}

function ContactColumn({
  icon, title, subtitle, tone, contacts,
}: {
  icon: React.ReactNode;
  title: string;
  subtitle: string;
  tone: "info" | "warning" | "accent";
  contacts: Contact[];
}) {
  const toneCls = {
    info: "bg-info/10 text-info border-info/30",
    warning: "bg-warning/15 text-warning border-warning/30",
    accent: "bg-accent/15 text-accent border-accent/30",
  }[tone];

  return (
    <Card className="flex flex-col">
      <CardHeader>
        <div className="flex items-center gap-2">
          <span className={`inline-flex h-9 w-9 items-center justify-center rounded-lg border ${toneCls}`}>{icon}</span>
          <div className="min-w-0">
            <CardTitle className="text-base">{title}</CardTitle>
            <CardDescription className="text-xs">{subtitle}</CardDescription>
          </div>
        </div>
      </CardHeader>
      <CardContent className="flex-1 space-y-2.5">
        {contacts.map((c) => (
          <div key={c.name} className="rounded-lg border bg-card p-3">
            <div className="text-[11px] font-medium uppercase tracking-wide text-muted-foreground">{c.role}</div>
            <div className="mt-0.5 font-semibold text-foreground">{c.name}</div>
            {c.note && <div className="mt-0.5 text-xs text-muted-foreground italic">{c.note}</div>}
            <div className="mt-2 flex flex-wrap gap-2">
              <a
                href={`tel:${c.tel.replace(/\s/g, "")}`}
                className="inline-flex items-center gap-1.5 rounded-md bg-primary px-3 py-1.5 text-xs font-semibold text-primary-foreground hover:bg-primary/90"
              >
                <Phone className="h-3.5 w-3.5" />
                {c.tel}
              </a>
              <button
                type="button"
                onClick={() => toast.success(`E-mail prioritaire transmis à ${c.name}.`)}
                className="inline-flex items-center gap-1.5 rounded-md border bg-card px-3 py-1.5 text-xs font-medium text-foreground hover:bg-accent"
              >
                <Mail className="h-3.5 w-3.5" />
                E-mail
              </button>
            </div>
          </div>
        ))}
      </CardContent>
    </Card>
  );
}
