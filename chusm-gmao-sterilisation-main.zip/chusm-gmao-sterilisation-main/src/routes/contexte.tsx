import { createFileRoute } from "@tanstack/react-router";
import {
  Droplets,
  Sparkles,
  Package,
  Flame,
  ShieldCheck,
  ScrollText,
  Building2,
  Stethoscope,
  HeartPulse,
  ChevronRight,
} from "lucide-react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";

export const Route = createFileRoute("/contexte")({
  head: () => ({
    meta: [
      { title: "Contexte Stratégique & Circuit des DM — CHUSM" },
      {
        name: "description",
        content:
          "Rôle stratégique de la stérilisation au CHU Souss-Massa, circuit des dispositifs médicaux et cadre réglementaire.",
      },
    ],
  }),
  component: ContextePage,
});

const steps = [
  {
    n: 1,
    title: "Pré-désinfection",
    detail:
      "Immersion immédiate des DM souillés dans une solution détergente-désinfectante au bloc opératoire.",
    icon: Droplets,
  },
  {
    n: 2,
    title: "Nettoyage",
    detail:
      "Lavage mécanique en laveur-désinfecteur thermique ou nettoyage par ultrasons selon le DM.",
    icon: Sparkles,
  },
  {
    n: 3,
    title: "Conditionnement & Emballage",
    detail:
      "Mise en sachets pelables ou en conteneurs rigides validés, avec indicateurs et traçabilité.",
    icon: Package,
  },
  {
    n: 4,
    title: "Stérilisation Autoclave",
    detail:
      "Vapeur d'eau saturée à 134 °C — Autoclaves Getinge GSS67H, cycles prion-compatibles.",
    icon: Flame,
  },
  {
    n: 5,
    title: "Contrôles & Validation",
    detail:
      "Tests physiques, indicateurs chimiques de classe 6, test de Bowie-Dick quotidien, libération paramétrique.",
    icon: ShieldCheck,
  },
];

const norms = [
  {
    code: "EN 285",
    title: "Stérilisateurs à grande capacité",
    detail: "Exigences et essais pour les stérilisateurs à vapeur d'eau de grande capacité hospitaliers.",
  },
  {
    code: "EN ISO 17665-1",
    title: "Stérilisation par chaleur humide",
    detail: "Développement, validation et contrôle de routine des procédés de stérilisation des DM.",
  },
  {
    code: "BPP",
    title: "Bonnes Pratiques de Pharmacie Hospitalière",
    detail: "Application des BPP à l'unité centrale de stérilisation du CHU Souss-Massa.",
  },
];

function ContextePage() {
  return (
    <div className="mx-auto max-w-[1600px] space-y-8 p-4 md:p-6">
      {/* Hero */}
      <section className="overflow-hidden rounded-2xl border bg-gradient-to-br from-primary/10 via-card to-accent/10 p-6 md:p-8">
        <div className="flex flex-wrap items-start justify-between gap-6">
          <div className="max-w-3xl">
            <Badge className="bg-primary text-primary-foreground">CHU Souss-Massa — CHUSM</Badge>
            <h1 className="mt-3 text-2xl font-bold tracking-tight md:text-3xl">
              Rôle stratégique de la stérilisation centrale
            </h1>
            <p className="mt-2 text-sm text-muted-foreground md:text-base">
              L'unité de stérilisation du CHUSM constitue un maillon critique de la chaîne de soins :
              elle garantit la sécurité microbiologique des dispositifs médicaux réutilisés au bloc
              opératoire, en endoscopie et dans les services de soins, conformément aux normes
              européennes et aux Bonnes Pratiques Pharmaceutiques.
            </p>
          </div>
          <div className="grid grid-cols-3 gap-3">
            <MiniStat icon={Building2} label="Sites desservis" value="CHU + CHR" />
            <MiniStat icon={Stethoscope} label="Blocs opératoires" value="12+" />
            <MiniStat icon={HeartPulse} label="Cycles / mois" value="~320" />
          </div>
        </div>
      </section>

      {/* Stepper */}
      <section>
        <div className="mb-4">
          <h2 className="text-xl font-bold tracking-tight">Circuit des Dispositifs Médicaux — 5 étapes</h2>
          <p className="text-sm text-muted-foreground">
            Protocole standard appliqué à la stérilisation centrale du CHUSM.
          </p>
        </div>

        <ol className="grid grid-cols-1 gap-3 md:grid-cols-2 xl:grid-cols-5">
          {steps.map((s, i) => {
            const Icon = s.icon;
            return (
              <li key={s.n} className="relative">
                <Card className="h-full border-l-4 border-l-primary transition hover:shadow-md">
                  <CardHeader className="pb-2">
                    <div className="flex items-center gap-3">
                      <span className="inline-flex h-10 w-10 items-center justify-center rounded-lg bg-primary/10 text-primary">
                        <Icon className="h-5 w-5" />
                      </span>
                      <div>
                        <div className="text-[11px] font-bold uppercase tracking-wider text-muted-foreground">
                          Étape {s.n}
                        </div>
                        <CardTitle className="text-base">{s.title}</CardTitle>
                      </div>
                    </div>
                  </CardHeader>
                  <CardContent>
                    <p className="text-sm text-muted-foreground">{s.detail}</p>
                  </CardContent>
                </Card>
                {i < steps.length - 1 && (
                  <ChevronRight className="absolute -right-3 top-1/2 hidden h-6 w-6 -translate-y-1/2 text-primary/40 xl:block" />
                )}
              </li>
            );
          })}
        </ol>
      </section>

      {/* Norms */}
      <section>
        <div className="mb-4 flex items-center gap-2">
          <ScrollText className="h-5 w-5 text-primary" />
          <h2 className="text-xl font-bold tracking-tight">Cadre réglementaire appliqué au CHUSM</h2>
        </div>
        <div className="grid grid-cols-1 gap-4 md:grid-cols-3">
          {norms.map((n) => (
            <Card key={n.code}>
              <CardHeader className="pb-2">
                <Badge variant="secondary" className="w-fit font-mono">
                  {n.code}
                </Badge>
                <CardTitle className="mt-2 text-base">{n.title}</CardTitle>
              </CardHeader>
              <CardContent>
                <CardDescription className="text-sm">{n.detail}</CardDescription>
              </CardContent>
            </Card>
          ))}
        </div>
      </section>
    </div>
  );
}

function MiniStat({
  icon: Icon,
  label,
  value,
}: {
  icon: typeof Building2;
  label: string;
  value: string;
}) {
  return (
    <div className="rounded-xl border bg-card/70 p-3 text-center backdrop-blur">
      <Icon className="mx-auto h-5 w-5 text-primary" />
      <div className="mt-1 text-base font-bold text-foreground">{value}</div>
      <div className="text-[10px] uppercase tracking-wider text-muted-foreground">{label}</div>
    </div>
  );
}
