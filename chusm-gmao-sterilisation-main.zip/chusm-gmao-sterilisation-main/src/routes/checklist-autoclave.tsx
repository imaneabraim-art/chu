import { createFileRoute } from "@tanstack/react-router";
import { ChecklistForm } from "@/components/ChecklistForm";
import { autoclaveChecklist } from "@/lib/data";

export const Route = createFileRoute("/checklist-autoclave")({
  head: () => ({ meta: [{ title: "Check-list Autoclave — CHUSM6A" }] }),
  component: () => (
    <ChecklistForm
      title="Check-list préventive — Autoclave"
      description="Maintenance journalière / hebdomadaire des autoclaves de stérilisation."
      items={autoclaveChecklist}
    />
  ),
});
