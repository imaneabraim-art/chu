import { createFileRoute } from "@tanstack/react-router";
import { ChecklistForm } from "@/components/ChecklistForm";
import { laveurChecklist } from "@/lib/data";

export const Route = createFileRoute("/checklist-laveur")({
  head: () => ({ meta: [{ title: "Check-list Laveur-Désinfecteur — CHUSM6A" }] }),
  component: () => (
    <ChecklistForm
      title="Check-list préventive — Laveur-Désinfecteur"
      description="Maintenance journalière / hebdomadaire des laveurs-désinfecteurs."
      items={laveurChecklist}
    />
  ),
});
