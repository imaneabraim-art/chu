import { createFileRoute } from "@tanstack/react-router";
import { useState, useSyncExternalStore } from "react";
import { Send, CheckCircle2, MessageSquareWarning, Inbox } from "lucide-react";
import { toast } from "sonner";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import {
  Select, SelectContent, SelectItem, SelectTrigger, SelectValue,
} from "@/components/ui/select";
import {
  Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle,
} from "@/components/ui/dialog";
import { ticketsStore, EQUIPMENTS, type Ticket } from "@/lib/data";

export const Route = createFileRoute("/reclamation")({
  head: () => ({ meta: [{ title: "Portail de Réclamation — CHUSM6A" }] }),
  component: ReclamationPage,
});

const CRITICITES: Ticket["criticite"][] = ["Basse", "Moyenne", "Haute", "Critique"];
const URGENCY_ORDER: Record<Ticket["criticite"], number> = { Critique: 0, Haute: 1, Moyenne: 2, Basse: 3 };

function ReclamationPage() {
  const tickets = useSyncExternalStore(
    ticketsStore.subscribe,
    () => ticketsStore.get(),
    () => ticketsStore.get(),
  );

  const [form, setForm] = useState({
    equipement: EQUIPMENTS[0],
    nature: "",
    criticite: "Moyenne" as Ticket["criticite"],
    declarant: "",
    description: "",
  });
  const [successOpen, setSuccessOpen] = useState(false);
  const [lastTicketId, setLastTicketId] = useState<string | null>(null);

  const submit = () => {
    if (!form.nature.trim() || !form.declarant.trim() || !form.description.trim()) {
      toast.error("Veuillez compléter l'ensemble des champs obligatoires.");
      return;
    }
    const t = ticketsStore.add(form);
    setLastTicketId(t.id);
    setSuccessOpen(true);
    setForm({ ...form, nature: "", description: "" });
  };

  const sorted = [...tickets].sort((a, b) => URGENCY_ORDER[a.criticite] - URGENCY_ORDER[b.criticite]);

  return (
    <div className="mx-auto max-w-[1600px] space-y-6 p-4 md:p-6">
      <div>
        <h1 className="text-2xl font-bold tracking-tight">Portail de Réclamation en Direct</h1>
        <p className="text-sm text-muted-foreground">
          Ticketing temps réel des pannes et dysfonctionnements — transmis au SEBM du CHU.
        </p>
      </div>

      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <MessageSquareWarning className="h-5 w-5 text-primary" />
            Signaler une nouvelle panne / Réclamation au SEBM
          </CardTitle>
          <CardDescription>
            Le ticket sera notifié à l'Ingénieur Biomédical Abdessamd Benbah ainsi qu'aux techniciens de garde.
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="grid grid-cols-1 gap-4 md:grid-cols-2">
            <div className="space-y-1.5">
              <Label>Équipement concerné *</Label>
              <Select value={form.equipement} onValueChange={(v) => setForm({ ...form, equipement: v })}>
                <SelectTrigger><SelectValue /></SelectTrigger>
                <SelectContent>
                  {EQUIPMENTS.map((e) => <SelectItem key={e} value={e}>{e}</SelectItem>)}
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-1.5">
              <Label>Criticité *</Label>
              <Select value={form.criticite} onValueChange={(v: Ticket["criticite"]) => setForm({ ...form, criticite: v })}>
                <SelectTrigger><SelectValue /></SelectTrigger>
                <SelectContent>
                  {CRITICITES.map((c) => <SelectItem key={c} value={c}>{c}</SelectItem>)}
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-1.5">
              <Label>Nature de la panne *</Label>
              <Input
                value={form.nature}
                onChange={(e) => setForm({ ...form, nature: e.target.value })}
                placeholder="Ex. Fuite vapeur, défaut IHM, alarme niveau chaudière…"
              />
            </div>
            <div className="space-y-1.5">
              <Label>Nom du déclarant *</Label>
              <Input
                value={form.declarant}
                onChange={(e) => setForm({ ...form, declarant: e.target.value })}
                placeholder="Ex. Majeure Ahlam, Tech. Mohamed…"
              />
            </div>
            <div className="space-y-1.5 md:col-span-2">
              <Label>Descriptif des symptômes *</Label>
              <Textarea
                rows={4}
                value={form.description}
                onChange={(e) => setForm({ ...form, description: e.target.value })}
                placeholder="Décrire précisément les symptômes observés, conditions, cycle concerné, message d'alarme affiché…"
              />
            </div>
          </div>
          <div className="flex justify-end">
            <Button size="lg" onClick={submit}>
              <Send className="h-4 w-4" />
              Envoyer la Réclamation
            </Button>
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Inbox className="h-5 w-5 text-primary" />
            Tableau des Réclamations actives
          </CardTitle>
          <CardDescription>Triées par criticité décroissante.</CardDescription>
        </CardHeader>
        <CardContent className="overflow-x-auto p-0">
          <table className="w-full text-sm">
            <thead className="bg-muted/50 text-left text-muted-foreground">
              <tr>
                <th className="px-4 py-3 font-medium">Ticket</th>
                <th className="px-4 py-3 font-medium">Date</th>
                <th className="px-4 py-3 font-medium">Équipement</th>
                <th className="px-4 py-3 font-medium">Nature</th>
                <th className="px-4 py-3 font-medium">Criticité</th>
                <th className="px-4 py-3 font-medium">Déclarant</th>
                <th className="px-4 py-3 font-medium">Statut</th>
              </tr>
            </thead>
            <tbody>
              {sorted.map((t) => (
                <tr key={t.id} className={`border-t ${t.criticite === "Critique" ? "bg-destructive/5" : ""}`}>
                  <td className="px-4 py-3 font-mono text-xs font-semibold">#{t.id}</td>
                  <td className="px-4 py-3 font-mono text-xs">{t.date}</td>
                  <td className="px-4 py-3 font-medium">{t.equipement}</td>
                  <td className="px-4 py-3">{t.nature}</td>
                  <td className="px-4 py-3"><CriticiteBadge c={t.criticite} /></td>
                  <td className="px-4 py-3">{t.declarant}</td>
                  <td className="px-4 py-3">
                    <Badge variant="outline">{t.statut}</Badge>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </CardContent>
      </Card>

      <Dialog open={successOpen} onOpenChange={setSuccessOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2 text-success">
              <CheckCircle2 className="h-6 w-6" />
              Réclamation transmise avec succès
            </DialogTitle>
            <DialogDescription className="pt-2 text-foreground">
              Réclamation transmise en temps réel au SEBM du CHU.
              <br />
              Ticket <span className="font-mono font-bold">#{lastTicketId}</span> généré.
              <br />
              Notification envoyée à l'Ingénieur Biomédical <span className="font-semibold">Abdessamd Benbah</span>.
            </DialogDescription>
          </DialogHeader>
          <DialogFooter>
            <Button onClick={() => setSuccessOpen(false)}>Fermer</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}

function CriticiteBadge({ c }: { c: Ticket["criticite"] }) {
  const map: Record<Ticket["criticite"], string> = {
    Critique: "bg-destructive text-destructive-foreground animate-pulse",
    Haute: "bg-destructive/85 text-destructive-foreground",
    Moyenne: "bg-warning text-warning-foreground",
    Basse: "bg-muted text-muted-foreground",
  };
  return <span className={`inline-flex rounded-md px-2.5 py-1 text-xs font-semibold ${map[c]}`}>{c}</span>;
}
