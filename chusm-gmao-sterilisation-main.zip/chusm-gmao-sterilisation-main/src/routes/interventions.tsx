import { createFileRoute } from "@tanstack/react-router";
import { useState } from "react";
import { Plus, ArrowLeft, Wrench, Droplets } from "lucide-react";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { ChecklistForm } from "@/components/ChecklistForm";
import { autoclaveChecklist, laveurChecklist } from "@/lib/data";

export const Route = createFileRoute("/interventions")({
  head: () => ({ meta: [{ title: "Interventions & Check-lists — CHUSM" }] }),
  component: InterventionsPage,
});

type Step = "landing" | "select" | "autoclave" | "laveur";

function InterventionsPage() {
  const [step, setStep] = useState<Step>("landing");

  if (step === "autoclave") {
    return (
      <div>
        <div className="mx-auto max-w-[1400px] px-4 pt-4 md:px-6 md:pt-6">
          <Button variant="ghost" size="sm" onClick={() => setStep("select")}>
            <ArrowLeft className="h-4 w-4" /> Retour à la sélection d'équipement
          </Button>
        </div>
        <ChecklistForm
          title="Check-list préventive — Autoclave Getinge GSS67H"
          description="Protocole technique 16 points — Maintenance journalière / hebdomadaire."
          items={autoclaveChecklist}
        />
      </div>
    );
  }

  if (step === "laveur") {
    return (
      <div>
        <div className="mx-auto max-w-[1400px] px-4 pt-4 md:px-6 md:pt-6">
          <Button variant="ghost" size="sm" onClick={() => setStep("select")}>
            <ArrowLeft className="h-4 w-4" /> Retour à la sélection d'équipement
          </Button>
        </div>
        <ChecklistForm
          title="Check-list préventive — Laveur-Désinfecteur Technique"
          description="Protocole technique 16 points — Maintenance hydraulique et chimique."
          items={laveurChecklist}
        />
      </div>
    );
  }

  return (
    <div className="mx-auto flex min-h-[calc(100vh-4rem)] max-w-[1400px] flex-col items-center justify-center gap-8 p-6">
      <div className="text-center">
        <h1 className="text-3xl font-bold tracking-tight">Module des Interventions Préventives</h1>
        <p className="mt-2 text-sm text-muted-foreground">
          Démarrer une nouvelle intervention de maintenance préventive sur un équipement de stérilisation.
        </p>
      </div>

      {step === "landing" && (
        <Button size="lg" className="h-16 px-8 text-lg font-semibold shadow-lg" onClick={() => setStep("select")}>
          <Plus className="h-6 w-6" /> Créer une nouvelle intervention
        </Button>
      )}

      {step === "select" && (
        <div className="grid w-full grid-cols-1 gap-6 md:grid-cols-2">
          <EquipmentCard
            icon={<Wrench className="h-10 w-10" />}
            title="Autoclave Getinge GSS67H"
            description="Stérilisation vapeur — chambre AISI 316L, générateur intégré, automatisme G1."
            onClick={() => setStep("autoclave")}
          />
          <EquipmentCard
            icon={<Droplets className="h-10 w-10" />}
            title="Laveur-Désinfecteur Technique"
            description="Pré-désinfection thermo-chimique — pompes de dosage, bras d'aspersion, module Booster."
            onClick={() => setStep("laveur")}
          />
        </div>
      )}
    </div>
  );
}

function EquipmentCard({
  icon, title, description, onClick,
}: { icon: React.ReactNode; title: string; description: string; onClick: () => void }) {
  return (
    <Card
      onClick={onClick}
      className="group cursor-pointer border-2 transition-all hover:border-primary hover:shadow-xl"
    >
      <CardContent className="flex flex-col items-center gap-4 p-8 text-center">
        <div className="flex h-20 w-20 items-center justify-center rounded-2xl bg-primary/10 text-primary transition-colors group-hover:bg-primary group-hover:text-primary-foreground">
          {icon}
        </div>
        <div>
          <div className="text-xl font-bold">{title}</div>
          <p className="mt-1 text-sm text-muted-foreground">{description}</p>
        </div>
        <span className="mt-2 text-sm font-semibold text-primary">Démarrer la check-list →</span>
      </CardContent>
    </Card>
  );
}
