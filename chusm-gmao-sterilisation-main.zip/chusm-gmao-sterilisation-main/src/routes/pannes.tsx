import { createFileRoute } from "@tanstack/react-router";
import { useState, useSyncExternalStore } from "react";
import { Plus, AlertCircle } from "lucide-react";
import { toast } from "sonner";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle, DialogTrigger,
} from "@/components/ui/dialog";
import {
  Select, SelectContent, SelectItem, SelectTrigger, SelectValue,
} from "@/components/ui/select";
import { pannesStore, type Panne } from "@/lib/data";

export const Route = createFileRoute("/pannes")({
  head: () => ({ meta: [{ title: "Historique des pannes — CHUSM6A" }] }),
  component: PannesPage,
});

function PannesPage() {
  const pannes = useSyncExternalStore(
    pannesStore.subscribe,
    () => pannesStore.get(),
    () => pannesStore.get(),
  );

  const sorted = [...pannes].sort((a, b) => b.date.localeCompare(a.date));
  const totalDowntime = pannes.reduce((s, p) => s + parseFloat(p.duree), 0);
  const open = pannes.filter((p) => p.statut !== "Réparé").length;

  return (
    <div className="mx-auto max-w-[1600px] space-y-6 p-4 md:p-6">
      <div className="flex flex-wrap items-start justify-between gap-3">
        <div>
          <h1 className="text-2xl font-bold tracking-tight">Historique des pannes & alertes</h1>
          <p className="text-sm text-muted-foreground">
            Journal des interventions de maintenance corrective.
          </p>
        </div>
        <NewPanneDialog />
      </div>

      <div className="grid grid-cols-1 gap-4 sm:grid-cols-3">
        <StatCard label="Total des pannes" value={pannes.length.toString()} />
        <StatCard label="Indisponibilité cumulée" value={`${totalDowntime.toFixed(1)} h`} />
        <StatCard label="Pannes ouvertes" value={open.toString()} tone={open > 0 ? "destructive" : "success"} />
      </div>

      <Card>
        <CardHeader>
          <CardTitle>Journal des pannes</CardTitle>
          <CardDescription>Trié du plus récent au plus ancien.</CardDescription>
        </CardHeader>
        <CardContent className="overflow-x-auto p-0">
          <table className="w-full text-sm">
            <thead className="bg-muted/50">
              <tr className="text-left text-muted-foreground">
                <th className="px-4 py-3 font-medium">Date</th>
                <th className="px-4 py-3 font-medium">Équipement</th>
                <th className="px-4 py-3 font-medium">Composant</th>
                <th className="px-4 py-3 font-medium">Gravité</th>
                <th className="px-4 py-3 font-medium">Durée</th>
                <th className="px-4 py-3 font-medium">Statut</th>
              </tr>
            </thead>
            <tbody>
              {sorted.map((p, i) => {
                const isOpen = p.statut !== "Réparé";
                return (
                  <tr
                    key={i}
                    className={`border-t ${isOpen ? "bg-destructive/5" : ""}`}
                  >
                    <td className="px-4 py-3 font-mono text-xs">{p.date}</td>
                    <td className="px-4 py-3 font-medium">{p.equipement}</td>
                    <td className="px-4 py-3">{p.composant}</td>
                    <td className="px-4 py-3">
                      <GraviteBadge g={p.gravite} />
                    </td>
                    <td className="px-4 py-3 tabular-nums">{p.duree}</td>
                    <td className="px-4 py-3">
                      {isOpen ? (
                        <span className="inline-flex items-center gap-1.5 rounded-md bg-destructive px-2.5 py-1 text-xs font-semibold text-destructive-foreground">
                          <AlertCircle className="h-3 w-3" />
                          {p.statut}
                        </span>
                      ) : (
                        <Badge className="bg-success text-success-foreground">{p.statut}</Badge>
                      )}
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </CardContent>
      </Card>
    </div>
  );
}

function GraviteBadge({ g }: { g: Panne["gravite"] }) {
  const map = {
    Haute: "bg-destructive text-destructive-foreground",
    Moyenne: "bg-warning text-warning-foreground",
    Basse: "bg-muted text-muted-foreground",
  } as const;
  return <span className={`inline-flex rounded-md px-2.5 py-1 text-xs font-semibold ${map[g]}`}>{g}</span>;
}

function StatCard({ label, value, tone = "default" }: { label: string; value: string; tone?: "default" | "destructive" | "success" }) {
  const color = tone === "destructive" ? "text-destructive" : tone === "success" ? "text-success" : "text-foreground";
  return (
    <Card>
      <CardContent className="p-5">
        <div className="text-xs font-medium uppercase tracking-wide text-muted-foreground">{label}</div>
        <div className={`mt-2 text-3xl font-bold tabular-nums ${color}`}>{value}</div>
      </CardContent>
    </Card>
  );
}

function NewPanneDialog() {
  const [open, setOpen] = useState(false);
  const [form, setForm] = useState<Panne>({
    date: new Date().toISOString().slice(0, 10),
    equipement: "Autoclave #1",
    composant: "",
    gravite: "Moyenne",
    duree: "",
    statut: "En cours / Non réparé",
  });

  const submit = () => {
    if (!form.composant || !form.duree) {
      toast.error("Veuillez compléter tous les champs.");
      return;
    }
    pannesStore.add(form);
    toast.success("Nouvelle panne déclarée.");
    setOpen(false);
    setForm({ ...form, composant: "", duree: "" });
  };

  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogTrigger asChild>
        <Button>
          <Plus className="h-4 w-4 mr-1.5" />
          Déclarer une nouvelle panne
        </Button>
      </DialogTrigger>
      <DialogContent>
        <DialogHeader>
          <DialogTitle>Déclarer une nouvelle panne</DialogTitle>
          <DialogDescription>Saisir les informations de l'incident.</DialogDescription>
        </DialogHeader>
        <div className="grid grid-cols-2 gap-3 py-2">
          <div className="space-y-1.5">
            <Label>Date</Label>
            <Input type="date" value={form.date} onChange={(e) => setForm({ ...form, date: e.target.value })} />
          </div>
          <div className="space-y-1.5">
            <Label>Équipement</Label>
            <Select value={form.equipement} onValueChange={(v) => setForm({ ...form, equipement: v })}>
              <SelectTrigger><SelectValue /></SelectTrigger>
              <SelectContent>
                {["Autoclave #1", "Autoclave #2", "Autoclave #3", "Laveur #1", "Laveur #2"].map((e) => (
                  <SelectItem key={e} value={e}>{e}</SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
          <div className="space-y-1.5 col-span-2">
            <Label>Composant en panne</Label>
            <Input value={form.composant} onChange={(e) => setForm({ ...form, composant: e.target.value })} placeholder="Ex. Joint de porte" />
          </div>
          <div className="space-y-1.5">
            <Label>Gravité</Label>
            <Select value={form.gravite} onValueChange={(v: Panne["gravite"]) => setForm({ ...form, gravite: v })}>
              <SelectTrigger><SelectValue /></SelectTrigger>
              <SelectContent>
                <SelectItem value="Haute">Haute</SelectItem>
                <SelectItem value="Moyenne">Moyenne</SelectItem>
                <SelectItem value="Basse">Basse</SelectItem>
              </SelectContent>
            </Select>
          </div>
          <div className="space-y-1.5">
            <Label>Durée d'indisponibilité</Label>
            <Input value={form.duree} onChange={(e) => setForm({ ...form, duree: e.target.value })} placeholder="Ex. 3h" />
          </div>
          <div className="space-y-1.5 col-span-2">
            <Label>Statut</Label>
            <Select value={form.statut} onValueChange={(v: Panne["statut"]) => setForm({ ...form, statut: v })}>
              <SelectTrigger><SelectValue /></SelectTrigger>
              <SelectContent>
                <SelectItem value="Réparé">Réparé</SelectItem>
                <SelectItem value="En cours / Non réparé">En cours / Non réparé</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </div>
        <DialogFooter>
          <Button variant="outline" onClick={() => setOpen(false)}>Annuler</Button>
          <Button onClick={submit}>Enregistrer</Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}
