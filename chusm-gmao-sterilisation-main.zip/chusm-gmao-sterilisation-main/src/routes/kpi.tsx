import { createFileRoute } from "@tanstack/react-router";
import {
  LineChart, Line, BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip,
  ResponsiveContainer, Legend, ReferenceLine,
} from "recharts";
import { Activity, CheckCircle2, AlertOctagon, Gauge, TrendingDown, TrendingUp } from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { monthlyKpis, TARGETS } from "@/lib/data";

export const Route = createFileRoute("/kpi")({
  head: () => ({
    meta: [
      { title: "Tableau de bord — Stérilisation CHUSM6A" },
      { name: "description", content: "KPIs mensuels de la stérilisation hospitalière." },
    ],
  }),
  component: Dashboard,
});

function Dashboard() {
  const latest = monthlyKpis[monthlyKpis.length - 1];
  const prev = monthlyKpis[monthlyKpis.length - 2];
  const totalComplaints = monthlyKpis.reduce((s, m) => s + m.complaints, 0);
  const avgConf =
    monthlyKpis.reduce((s, m) => s + m.conformity, 0) / monthlyKpis.length;
  const avgAvail =
    monthlyKpis.reduce((s, m) => s + m.availability, 0) / monthlyKpis.length;

  return (
    <div className="mx-auto max-w-[1600px] space-y-6 p-4 md:p-6">
      <div>
        <h1 className="text-2xl font-bold tracking-tight">Tableau de bord — KPIs mensuels</h1>
        <p className="text-sm text-muted-foreground">
          Vue d'ensemble de la performance du service stérilisation (6 derniers mois).
        </p>
      </div>

      <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-4">
        <KpiCard
          icon={<Activity className="h-5 w-5" />}
          label="Cycles (mois en cours)"
          value={latest.cycles.toString()}
          delta={latest.cycles - prev.cycles}
          deltaSuffix="vs mois précédent"
          accent="info"
        />
        <KpiCard
          icon={<CheckCircle2 className="h-5 w-5" />}
          label="Conformité moyenne"
          value={`${avgConf.toFixed(1)}%`}
          badge={
            avgConf >= TARGETS.conformity
              ? { text: `≥ ${TARGETS.conformity}% ✓`, tone: "success" }
              : { text: `< ${TARGETS.conformity}% ⚠`, tone: "warning" }
          }
          accent="success"
        />
        <KpiCard
          icon={<AlertOctagon className="h-5 w-5" />}
          label="Réclamations du bloc (total)"
          value={totalComplaints.toString()}
          delta={latest.complaints - prev.complaints}
          deltaSuffix="vs mois précédent"
          invertDelta
          accent="destructive"
        />
        <KpiCard
          icon={<Gauge className="h-5 w-5" />}
          label="Disponibilité moyenne"
          value={`${avgAvail.toFixed(1)}%`}
          badge={
            avgAvail >= TARGETS.availability
              ? { text: `≥ ${TARGETS.availability}% ✓`, tone: "success" }
              : { text: `< ${TARGETS.availability}% ⚠`, tone: "warning" }
          }
          accent="accent"
        />
      </div>

      <Card>
        <CardHeader>
          <CardTitle>Évolution mensuelle</CardTitle>
          <CardDescription>
            Suivi des cycles, conformité, réclamations et disponibilité avec seuils cibles.
          </CardDescription>
        </CardHeader>
        <CardContent>
          <Tabs defaultValue="conformity" className="w-full">
            <TabsList className="mb-4">
              <TabsTrigger value="conformity">Conformité & Disponibilité</TabsTrigger>
              <TabsTrigger value="cycles">Cycles</TabsTrigger>
              <TabsTrigger value="complaints">Réclamations</TabsTrigger>
            </TabsList>

            <TabsContent value="conformity">
              <ChartWrap>
                <LineChart data={monthlyKpis}>
                  <CartesianGrid strokeDasharray="3 3" className="stroke-border" />
                  <XAxis dataKey="month" />
                  <YAxis domain={[88, 100]} unit="%" />
                  <Tooltip />
                  <Legend />
                  <ReferenceLine
                    y={TARGETS.conformity}
                    stroke="var(--color-success)"
                    strokeDasharray="4 4"
                    label={{ value: `Cible conformité ${TARGETS.conformity}%`, position: "insideTopLeft", fontSize: 11 }}
                  />
                  <ReferenceLine
                    y={TARGETS.availability}
                    stroke="var(--color-warning)"
                    strokeDasharray="4 4"
                    label={{ value: `Cible disponibilité ${TARGETS.availability}%`, position: "insideBottomLeft", fontSize: 11 }}
                  />
                  <Line type="monotone" dataKey="conformity" name="Conformité %" stroke="var(--color-chart-1)" strokeWidth={2.5} dot={{ r: 4 }} />
                  <Line type="monotone" dataKey="availability" name="Disponibilité %" stroke="var(--color-chart-4)" strokeWidth={2.5} dot={{ r: 4 }} />
                </LineChart>
              </ChartWrap>
            </TabsContent>

            <TabsContent value="cycles">
              <ChartWrap>
                <BarChart data={monthlyKpis}>
                  <CartesianGrid strokeDasharray="3 3" className="stroke-border" />
                  <XAxis dataKey="month" />
                  <YAxis />
                  <Tooltip />
                  <Legend />
                  <Bar dataKey="cycles" name="Nombre de cycles" fill="var(--color-chart-1)" radius={[6, 6, 0, 0]} />
                </BarChart>
              </ChartWrap>
            </TabsContent>

            <TabsContent value="complaints">
              <ChartWrap>
                <BarChart data={monthlyKpis}>
                  <CartesianGrid strokeDasharray="3 3" className="stroke-border" />
                  <XAxis dataKey="month" />
                  <YAxis allowDecimals={false} />
                  <Tooltip />
                  <Legend />
                  <Bar dataKey="complaints" name="Réclamations" fill="var(--color-chart-3)" radius={[6, 6, 0, 0]} />
                </BarChart>
              </ChartWrap>
            </TabsContent>
          </Tabs>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>Détail mensuel</CardTitle>
        </CardHeader>
        <CardContent className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead>
              <tr className="border-b text-left text-muted-foreground">
                <th className="px-3 py-2 font-medium">Mois</th>
                <th className="px-3 py-2 font-medium">Cycles</th>
                <th className="px-3 py-2 font-medium">Conformité</th>
                <th className="px-3 py-2 font-medium">Réclamations</th>
                <th className="px-3 py-2 font-medium">Disponibilité</th>
              </tr>
            </thead>
            <tbody>
              {monthlyKpis.map((m) => (
                <tr key={m.month} className="border-b last:border-0">
                  <td className="px-3 py-2 font-medium">{m.month}</td>
                  <td className="px-3 py-2">{m.cycles}</td>
                  <td className="px-3 py-2">
                    <span className={m.conformity < TARGETS.conformity ? "text-warning font-semibold" : ""}>
                      {m.conformity}%
                    </span>
                    {m.conformity < TARGETS.conformity && (
                      <Badge variant="outline" className="ml-2 border-warning text-warning">Sous cible</Badge>
                    )}
                  </td>
                  <td className="px-3 py-2">
                    {m.complaints}
                    {m.complaintsAlert && (
                      <Badge variant="outline" className="ml-2 border-destructive text-destructive">Pic Réclamations Blocs</Badge>
                    )}
                  </td>
                  <td className="px-3 py-2">
                    <span className={m.availability < TARGETS.availability ? "text-destructive font-semibold" : ""}>
                      {m.availability}%
                    </span>
                    {m.availability < TARGETS.availability && (
                      <Badge variant="outline" className="ml-2 border-destructive text-destructive">Sous cible</Badge>
                    )}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </CardContent>
      </Card>
    </div>
  );
}

function ChartWrap({ children }: { children: React.ReactElement }) {
  return (
    <div className="h-[340px] w-full">
      <ResponsiveContainer width="100%" height="100%">
        {children}
      </ResponsiveContainer>
    </div>
  );
}

function KpiCard({
  icon, label, value, delta, deltaSuffix, invertDelta, badge, accent,
}: {
  icon: React.ReactNode;
  label: string;
  value: string;
  delta?: number;
  deltaSuffix?: string;
  invertDelta?: boolean;
  badge?: { text: string; tone: "success" | "warning" };
  accent: "info" | "success" | "destructive" | "accent";
}) {
  const accentBg = {
    info: "bg-info/10 text-info",
    success: "bg-success/10 text-success",
    destructive: "bg-destructive/10 text-destructive",
    accent: "bg-accent/15 text-accent",
  }[accent];

  const positive = delta !== undefined && (invertDelta ? delta < 0 : delta > 0);
  const negative = delta !== undefined && (invertDelta ? delta > 0 : delta < 0);

  return (
    <Card>
      <CardContent className="p-5">
        <div className="flex items-start justify-between">
          <div className="min-w-0">
            <div className="text-xs font-medium uppercase tracking-wide text-muted-foreground">
              {label}
            </div>
            <div className="mt-2 text-3xl font-bold tabular-nums tracking-tight">{value}</div>
            {delta !== undefined && (
              <div className="mt-1 flex items-center gap-1 text-xs">
                {positive && <TrendingUp className="h-3.5 w-3.5 text-success" />}
                {negative && <TrendingDown className="h-3.5 w-3.5 text-destructive" />}
                <span className={positive ? "text-success" : negative ? "text-destructive" : "text-muted-foreground"}>
                  {delta > 0 ? "+" : ""}{delta} {deltaSuffix}
                </span>
              </div>
            )}
            {badge && (
              <Badge
                className={`mt-2 ${badge.tone === "success" ? "bg-success text-success-foreground" : "bg-warning text-warning-foreground"}`}
              >
                {badge.text}
              </Badge>
            )}
          </div>
          <div className={`flex h-10 w-10 items-center justify-center rounded-lg ${accentBg}`}>
            {icon}
          </div>
        </div>
      </CardContent>
    </Card>
  );
}
