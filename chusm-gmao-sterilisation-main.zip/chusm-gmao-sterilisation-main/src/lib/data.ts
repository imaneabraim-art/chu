export const monthlyKpis = [
  { month: "Nov", cycles: 320, conformity: 98.5, complaints: 2, availability: 95.5, warning: false, complaintsAlert: false },
  { month: "Déc", cycles: 310, conformity: 97.8, complaints: 3, availability: 94.8, warning: false, complaintsAlert: false },
  { month: "Jan", cycles: 345, conformity: 96.2, complaints: 5, availability: 92.1, warning: true, complaintsAlert: false },
  { month: "Fév", cycles: 290, conformity: 98.1, complaints: 2, availability: 95.2, warning: false, complaintsAlert: false },
  { month: "Mar", cycles: 330, conformity: 97.5, complaints: 3, availability: 94.5, warning: false, complaintsAlert: false },
  { month: "Avr", cycles: 315, conformity: 96.4, complaints: 4, availability: 93.2, warning: false, complaintsAlert: false },
  { month: "Mai", cycles: 310, conformity: 97.8, complaints: 6, availability: 94.8, warning: false, complaintsAlert: true },
];

export const TARGETS = { conformity: 97, availability: 95 };

export type Panne = {
  date: string;
  equipement: string;
  composant: string;
  gravite: "Haute" | "Moyenne" | "Basse";
  duree: string;
  statut: "Réparé" | "En cours / Non réparé";
};

export const pannesInitial: Panne[] = [
  { date: "2025-11-15", equipement: "Autoclave #3", composant: "Joint de porte", gravite: "Haute", duree: "5.5h", statut: "Réparé" },
  { date: "2025-12-02", equipement: "Autoclave #1", composant: "Soupape", gravite: "Moyenne", duree: "2.5h", statut: "Réparé" },
  { date: "2025-12-12", equipement: "Laveur #2", composant: "Buses bouchées", gravite: "Moyenne", duree: "3h", statut: "Réparé" },
  { date: "2026-01-05", equipement: "Autoclave #3", composant: "Générateur vapeur", gravite: "Haute", duree: "8h", statut: "Réparé" },
  { date: "2026-01-18", equipement: "Autoclave #2", composant: "Relais niveau", gravite: "Basse", duree: "1.5h", statut: "Réparé" },
  { date: "2026-02-10", equipement: "Laveur #2", composant: "Pompe circulation", gravite: "Haute", duree: "4h", statut: "Réparé" },
  { date: "2026-03-22", equipement: "Autoclave #3", composant: "Soupape", gravite: "Haute", duree: "4.2h", statut: "Réparé" },
  { date: "2026-04-05", equipement: "Autoclave #2", composant: "Joint porte", gravite: "Basse", duree: "2h", statut: "Réparé" },
  { date: "2026-04-23", equipement: "Autoclave #2", composant: "Générateur vapeur", gravite: "Haute", duree: "8h", statut: "Réparé" },
  { date: "2026-04-29", equipement: "Paillasse d'eau", composant: "Pistolet d'eau", gravite: "Basse", duree: "2h", statut: "Réparé" },
  { date: "2026-04-29", equipement: "Traitement d'eau", composant: "Adoucisseur", gravite: "Basse", duree: "1.5h", statut: "Réparé" },
  { date: "2026-04-29", equipement: "Autoclave #1", composant: "Durée du vide", gravite: "Haute", duree: "6h", statut: "Réparé" },
  { date: "2026-05-14", equipement: "Autoclave #3", composant: "Générateur vapeur", gravite: "Haute", duree: "6h", statut: "Réparé" },
  { date: "2026-05-18", equipement: "Autoclave #3", composant: "Joint de porte (incident majeur 72h)", gravite: "Haute", duree: "72h", statut: "Réparé" },
  { date: "2026-05-23", equipement: "Autoclave #3", composant: "Joint de porte", gravite: "Haute", duree: "23h", statut: "Réparé" },
  { date: "2026-06-07", equipement: "Traitement d'eau", composant: "Pompe", gravite: "Haute", duree: "8h", statut: "En cours / Non réparé" },
];

export const autoclaveChecklist = [
  "Vidanger le générateur de vapeur",
  "Fonctionnement soupapes de sécurité",
  "Nettoyage surface autoclave",
  "Fonctionnement distributeur air",
  "Fonctionnement vannes pneumatiques",
  "Pompe à vide",
  "Pompe de remplissage",
  "Vérin pneumatique portes",
  "Nettoyage joint étanchéité",
  "Lubrification guide porte",
  "Equilibrage porte",
  "Coffret électrique",
  "Relais de niveau",
  "Verrouillage des portes",
  "Ecran tactile",
  "Absence de fuites raccordements",
];

export const laveurChecklist = [
  "Vidanger chambre de lavage",
  "Pompes de dosage",
  "Nettoyage surface laveur",
  "Capteur niveau produit",
  "Booster",
  "Pompe de circulation",
  "Pompe de vidange",
  "Moteur de séchage",
  "Nettoyage joint étanchéité",
  "Bras aspersion",
  "Equilibrage chariot",
  "Coffret électrique",
  "Ecran tactile",
  "Verrouillage portes",
  "Eclairage chambre",
  "Absence de fuites",
];

// ============== ORGANISATION & CONTACTS ==============

export type Contact = { role: string; name: string; tel: string; note?: string };

export const contactsSEBM: Contact[] = [
  { role: "Ingénieur Biomédical — Responsable SEBM", name: "Abdessamd Benbah", tel: "0655430418" },
  { role: "Technicien Biomédical CHU", name: "Mohamed", tel: "0602027092" },
  { role: "Technicien Biomédical CHU", name: "Ibrahim", tel: "0657713004" },
];

export const contactsMedexel: Contact[] = [
  { role: "Expert Getinge — Medexel", name: "Elarbi", tel: "Support Medexel Maroc" },
  { role: "Expert Getinge — Medexel", name: "Hamza", tel: "Support Medexel Maroc" },
  { role: "Hotline Medexel S.A. (Getinge)", name: "Support Technique", tel: "Standard Medexel" },
];

export const contactsSterilisation: Contact[] = [
  { role: "Majeure du service Stérilisation", name: "Ahlam", tel: "0774000125", note: "Coordination des kits chirurgicaux bloqués" },
];

// ============== TICKETS RÉCLAMATION ==============

export type Ticket = {
  id: string;
  date: string;
  equipement: string;
  nature: string;
  criticite: "Basse" | "Moyenne" | "Haute" | "Critique";
  declarant: string;
  description: string;
  statut: "Ouvert" | "En cours" | "Résolu";
};

let _tickets: Ticket[] = [
  {
    id: "2026-CHUSM-ST-01",
    date: "2026-06-07",
    equipement: "Traitement d'eau",
    nature: "Pompe HS — alimentation eau osmosée interrompue",
    criticite: "Critique",
    declarant: "Majeure Ahlam",
    description: "Pompe du traitement d'eau hors service depuis le 07/06. Risque d'arrêt de production stérile.",
    statut: "En cours",
  },
  {
    id: "2026-CHUSM-ST-02",
    date: "2026-05-23",
    equipement: "Autoclave Getinge GSS67H #3",
    nature: "Reprise fuite joint de porte (23h)",
    criticite: "Haute",
    declarant: "Tech. Mohamed",
    description: "Récidive fuite vapeur après remplacement joint suite à l'incident majeur du 18/05 (72h).",
    statut: "Résolu",
  },
];

const ticketsListeners = new Set<() => void>();

export const ticketsStore = {
  get: () => _tickets,
  add: (t: Omit<Ticket, "id" | "date" | "statut">) => {
    const seq = (_tickets.length + 1).toString().padStart(2, "0");
    const ticket: Ticket = {
      ...t,
      id: `2026-CHUSM-ST-${seq}`,
      date: new Date().toISOString().slice(0, 10),
      statut: "Ouvert",
    };
    _tickets = [ticket, ..._tickets];
    ticketsListeners.forEach((l) => l());
    return ticket;
  },
  subscribe: (l: () => void) => {
    ticketsListeners.add(l);
    return () => ticketsListeners.delete(l);
  },
};

// ============== PANNES STORE (legacy) ==============

type Listener = () => void;
const listeners = new Set<Listener>();
let _pannes: Panne[] = [...pannesInitial];

export const pannesStore = {
  get: () => _pannes,
  add: (p: Panne) => {
    _pannes = [..._pannes, p];
    listeners.forEach((l) => l());
  },
  subscribe: (l: Listener) => {
    listeners.add(l);
    return () => listeners.delete(l);
  },
};

export const EQUIPMENTS = [
  "Autoclave Getinge GSS67H #1",
  "Autoclave Getinge GSS67H #2",
  "Autoclave Getinge GSS67H #3",
  "Laveur-Désinfecteur #1",
  "Laveur-Désinfecteur #2",
  "Traitement d'eau",
  "Paillasse d'eau",
];
