import { useRef, useState } from "react";
import { CheckCircle2, XCircle, Eraser } from "lucide-react";
import { toast } from "sonner";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";

type State = Record<number, { value: "OUI" | "NON" | null; note: string }>;

export function ChecklistForm({ title, description, items }: { title: string; description: string; items: string[] }) {
  const [state, setState] = useState<State>(() =>
    Object.fromEntries(items.map((_, i) => [i, { value: null, note: "" }])),
  );
  const [technician, setTechnician] = useState("");
  const [date, setDate] = useState(new Date().toISOString().slice(0, 10));

  const canvasRef = useRef<HTMLCanvasElement>(null);
  const drawing = useRef(false);
  const hasSig = useRef(false);

  const setRow = (i: number, patch: Partial<State[number]>) =>
    setState((s) => ({ ...s, [i]: { ...s[i], ...patch } }));

  const total = items.length;
  const answered = Object.values(state).filter((r) => r.value).length;
  const oui = Object.values(state).filter((r) => r.value === "OUI").length;
  const non = Object.values(state).filter((r) => r.value === "NON").length;
  const conformity = answered ? Math.round((oui / answered) * 100) : 0;

  const startDraw = (e: React.PointerEvent<HTMLCanvasElement>) => {
    const c = canvasRef.current!;
    drawing.current = true;
    hasSig.current = true;
    const rect = c.getBoundingClientRect();
    const ctx = c.getContext("2d")!;
    ctx.strokeStyle = "oklch(0.22 0.04 250)";
    ctx.lineWidth = 2;
    ctx.lineCap = "round";
    ctx.beginPath();
    ctx.moveTo(e.clientX - rect.left, e.clientY - rect.top);
  };
  const draw = (e: React.PointerEvent<HTMLCanvasElement>) => {
    if (!drawing.current) return;
    const c = canvasRef.current!;
    const rect = c.getBoundingClientRect();
    const ctx = c.getContext("2d")!;
    ctx.lineTo(e.clientX - rect.left, e.clientY - rect.top);
    ctx.stroke();
  };
  const endDraw = () => { drawing.current = false; };
  const clearSig = () => {
    const c = canvasRef.current!;
    c.getContext("2d")!.clearRect(0, 0, c.width, c.height);
    hasSig.current = false;
  };

  const validate = () => {
    if (answered < total) {
      toast.error(`Veuillez compléter tous les points (${answered}/${total}).`);
      return;
    }
    if (!technician.trim()) {
      toast.error("Veuillez saisir le nom du technicien.");
      return;
    }
    if (!hasSig.current) {
      toast.error("Veuillez signer la check-list.");
      return;
    }
    toast.success(`Check-list validée — ${conformity}% de conformité (${oui}/${total}).`);
  };

  return (
    <div className="mx-auto max-w-[1400px] space-y-6 p-4 md:p-6">
      <div>
        <h1 className="text-2xl font-bold tracking-tight">{title}</h1>
        <p className="text-sm text-muted-foreground">{description}</p>
      </div>

      <div className="grid grid-cols-2 gap-4 md:grid-cols-4">
        <Stat label="Points contrôlés" value={`${answered}/${total}`} />
        <Stat label="Conformes (OUI)" value={oui.toString()} tone="success" />
        <Stat label="Non conformes (NON)" value={non.toString()} tone="destructive" />
        <Stat label="Taux de conformité" value={`${conformity}%`} tone={conformity >= 90 ? "success" : "warning"} />
      </div>

      <Card>
        <CardHeader>
          <CardTitle>Points de contrôle</CardTitle>
          <CardDescription>
            Cochez OUI ou NON pour chaque point. En cas de non-conformité, précisez les observations.
          </CardDescription>
        </CardHeader>
        <CardContent className="p-0">
          <ul className="divide-y">
            {items.map((label, i) => {
              const row = state[i];
              const isNo = row.value === "NON";
              return (
                <li
                  key={i}
                  className={`flex flex-col gap-3 px-4 py-3 transition-colors md:flex-row md:items-start ${
                    isNo ? "bg-warning/10" : ""
                  }`}
                >
                  <div className="flex flex-1 items-center gap-3">
                    <span className="inline-flex h-6 w-6 shrink-0 items-center justify-center rounded-full bg-muted text-xs font-semibold text-muted-foreground">
                      {i + 1}
                    </span>
                    <span className="text-sm font-medium">{label}</span>
                  </div>
                  <div className="flex shrink-0 items-center gap-2">
                    <ChoiceButton
                      active={row.value === "OUI"}
                      tone="success"
                      onClick={() => setRow(i, { value: "OUI", note: "" })}
                    >
                      <CheckCircle2 className="h-4 w-4" /> OUI
                    </ChoiceButton>
                    <ChoiceButton
                      active={row.value === "NON"}
                      tone="destructive"
                      onClick={() => setRow(i, { value: "NON" })}
                    >
                      <XCircle className="h-4 w-4" /> NON
                    </ChoiceButton>
                  </div>
                  {isNo && (
                    <div className="basis-full md:basis-auto md:w-80">
                      <Textarea
                        placeholder="Observations / Actions requises"
                        value={row.note}
                        onChange={(e) => setRow(i, { note: e.target.value })}
                        className="min-h-[60px] border-warning/60 bg-card"
                      />
                    </div>
                  )}
                </li>
              );
            })}
          </ul>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>Validation de la check-list</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="grid grid-cols-1 gap-4 md:grid-cols-2">
            <div className="space-y-1.5">
              <Label>Date</Label>
              <Input type="date" value={date} onChange={(e) => setDate(e.target.value)} />
            </div>
            <div className="space-y-1.5">
              <Label>Nom du technicien</Label>
              <Input value={technician} onChange={(e) => setTechnician(e.target.value)} placeholder="Ex. M. Y. Benali" />
            </div>
          </div>
          <div className="space-y-1.5">
            <div className="flex items-center justify-between">
              <Label>Signature numérique</Label>
              <Button type="button" variant="ghost" size="sm" onClick={clearSig}>
                <Eraser className="h-4 w-4 mr-1" /> Effacer
              </Button>
            </div>
            <canvas
              ref={canvasRef}
              width={800}
              height={160}
              className="w-full touch-none rounded-md border bg-card"
              onPointerDown={startDraw}
              onPointerMove={draw}
              onPointerUp={endDraw}
              onPointerLeave={endDraw}
            />
            <p className="text-xs text-muted-foreground">
              Signez dans le cadre ci-dessus à l'aide de la souris ou du stylet tactile.
            </p>
          </div>
          <div className="flex justify-end">
            <Button size="lg" onClick={validate}>Valider la check-list</Button>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}

function ChoiceButton({
  active, tone, onClick, children,
}: { active: boolean; tone: "success" | "destructive"; onClick: () => void; children: React.ReactNode }) {
  const base = "inline-flex items-center gap-1.5 rounded-md px-3 py-1.5 text-sm font-semibold border transition";
  const activeCls =
    tone === "success"
      ? "bg-success text-success-foreground border-success"
      : "bg-destructive text-destructive-foreground border-destructive";
  const idle =
    tone === "success"
      ? "bg-card text-success border-success/40 hover:bg-success/10"
      : "bg-card text-destructive border-destructive/40 hover:bg-destructive/10";
  return (
    <button type="button" onClick={onClick} className={`${base} ${active ? activeCls : idle}`}>
      {children}
    </button>
  );
}

function Stat({ label, value, tone = "default" }: { label: string; value: string; tone?: "default" | "success" | "destructive" | "warning" }) {
  const color = {
    default: "text-foreground",
    success: "text-success",
    destructive: "text-destructive",
    warning: "text-warning",
  }[tone];
  return (
    <Card>
      <CardContent className="p-4">
        <div className="text-xs font-medium uppercase tracking-wide text-muted-foreground">{label}</div>
        <div className={`mt-1 text-2xl font-bold tabular-nums ${color}`}>{value}</div>
      </CardContent>
    </Card>
  );
}
