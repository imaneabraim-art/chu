import { useEffect, useState, useSyncExternalStore } from "react";
import { AlertTriangle, Phone, X } from "lucide-react";
import { pannesStore } from "@/lib/data";
import { Button } from "@/components/ui/button";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";

export function CriticalAlertBanner() {
  const [mounted, setMounted] = useState(false);
  useEffect(() => setMounted(true), []);

  const pannes = useSyncExternalStore(
    pannesStore.subscribe,
    () => pannesStore.get(),
    () => pannesStore.get(),
  );

  const [open, setOpen] = useState(false);
  const [dismissed, setDismissed] = useState(false);

  if (!mounted) return null;

  const critical = pannes.find((p) => p.statut !== "Réparé");
  if (!critical || dismissed) return null;

  return (
    <>
      <div className="animate-critical-flash text-destructive-foreground">
        <div className="mx-auto flex max-w-[1600px] flex-wrap items-center gap-3 px-4 py-2.5">
          <AlertTriangle className="h-5 w-5 shrink-0" />
          <div className="flex-1 min-w-0 text-sm">
            <span className="font-bold uppercase tracking-wide">Alerte critique :</span>{" "}
            <span className="font-medium">
              {critical.equipement} — {critical.composant} — Indisponible depuis {critical.duree} ({critical.statut})
            </span>
          </div>
          <Button
            size="sm"
            variant="secondary"
            className="bg-white text-destructive hover:bg-white/90 font-semibold shadow"
            onClick={() => setOpen(true)}
          >
            <Phone className="h-4 w-4 mr-1.5" />
            Appeler le Responsable Technique
          </Button>
          <button
            onClick={() => setDismissed(true)}
            className="ml-1 rounded p-1 hover:bg-white/15"
            aria-label="Fermer"
          >
            <X className="h-4 w-4" />
          </button>
        </div>
      </div>

      <Dialog open={open} onOpenChange={setOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2 text-destructive">
              <Phone className="h-5 w-5" />
              Contact d'urgence — Responsable Technique
            </DialogTitle>
            <DialogDescription>
              Intervention prioritaire requise sur {critical.equipement}.
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-3 pt-2">
            <ContactRow label="Responsable SEBM — Ingénieur Biomédical" name="Abdessamd Benbah" tel="0655430418" />
            <ContactRow label="Technicien Biomédical CHU" name="Mohamed" tel="0602027092" />
            <ContactRow label="Technicien Biomédical CHU" name="Ibrahim" tel="0657713004" />
            <ContactRow label="Majeure Stérilisation" name="Ahlam" tel="0774000125" />
            <ContactRow label="Prestataire Externe — Medexel (Getinge)" name="Experts Elarbi & Hamza" tel="Support Medexel" />
          </div>
        </DialogContent>
      </Dialog>
    </>
  );
}

function ContactRow({ label, name, tel }: { label: string; name: string; tel: string }) {
  return (
    <div className="flex items-center justify-between rounded-lg border bg-card p-3">
      <div>
        <div className="text-xs uppercase tracking-wide text-muted-foreground">{label}</div>
        <div className="font-semibold">{name}</div>
      </div>
      <a
        href={`tel:${tel.replace(/\s/g, "")}`}
        className="inline-flex items-center gap-1.5 rounded-md bg-destructive px-3 py-1.5 text-sm font-medium text-destructive-foreground hover:opacity-90"
      >
        <Phone className="h-3.5 w-3.5" />
        {tel}
      </a>
    </div>
  );
}
